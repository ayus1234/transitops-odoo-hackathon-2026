import React from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Navbar from './Navbar';

const MainLayout = () => {
  return (
    <div className="flex min-h-screen bg-background text-on-surface overflow-hidden">
      <Sidebar />
      <main className="flex-1 ml-[240px] flex flex-col min-h-screen relative">
        <Navbar />
        {/* Page Content injected via Outlet */}
        <Outlet />
      </main>
    </div>
  );
};

export default MainLayout;
