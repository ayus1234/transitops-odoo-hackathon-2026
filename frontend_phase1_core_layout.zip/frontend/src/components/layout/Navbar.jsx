import React from 'react';
import { useLocation } from 'react-router-dom';

const Navbar = () => {
  const location = useLocation();
  const path = location.pathname.substring(1); // remove leading slash
  const title = path.charAt(0).toUpperCase() + path.slice(1);

  return (
    <header className="flex justify-between items-center h-16 px-md w-full sticky top-0 z-50 bg-surface border-b border-outline-variant shadow-sm">
      <div className="flex items-center gap-md flex-1">
        <div className="relative w-full max-w-md">
          <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline">search</span>
          <input 
            className="w-full bg-surface-container-low border border-outline-variant rounded-lg pl-10 pr-4 py-1.5 text-body-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all" 
            placeholder={`Search ${title || 'TransitOps'}...`} 
            type="text"
          />
        </div>
        <div className="flex items-center gap-sm text-on-surface-variant font-title-sm text-title-sm ml-4">
          <span className="cursor-pointer hover:text-primary transition-colors">Workspace</span>
          <span className="text-outline">/</span>
          <span className="font-bold text-primary border-b-2 border-primary pb-0.5">{title || 'Dashboard'}</span>
        </div>
      </div>
      <div className="flex items-center gap-md">
        <div className="flex items-center gap-sm mr-2">
          <button className="p-2 rounded-full hover:bg-surface-container-high transition-all text-on-surface-variant">
            <span className="material-symbols-outlined">notifications</span>
          </button>
          <button className="p-2 rounded-full hover:bg-surface-container-high transition-all text-on-surface-variant">
            <span className="material-symbols-outlined">help</span>
          </button>
        </div>
        {/* Dynamic primary action button could be added here based on props, but we keep it static or hidden for now */}
        <button className="bg-primary text-on-primary px-4 py-2 rounded font-bold text-body-sm hover:opacity-90 active:scale-95 transition-all flex items-center gap-sm shadow-sm">
          <span className="material-symbols-outlined text-[18px]">add</span>
          New Action
        </button>
      </div>
    </header>
  );
};

export default Navbar;
